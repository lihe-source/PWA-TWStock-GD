# 股序 V1_2 原始碼

這是 SOURCE.zip 的內容。手機部署請直接使用外層扁平發佈包，設定步驟見 SETUP.md。

技術：React / TypeScript / Vite / ECharts；Python 標準函式庫抓取官方免費資料。私人分類、筆記與條件透過 IndexedDB 與選用的 Google Drive 同步。

## 在電腦修改與重新產出扁平版

需要 Node.js 22+、Python 3.11+。將 SOURCE.zip 解壓到獨立資料夾。以下 `../flat` 指外層完整扁平資料夾（其中包含 market.json、32 個 history-XX.json 與 PIPELINE_STATE.zip）。

```bash
python3 scripts/flat_data.py unpack --flat ../flat --project .
npm ci
npm run check
npm run build
python3 scripts/validate_release.py
python3 scripts/make_flat_release.py ../PWA-TWStock-GD-V1_2-FLAT
```

最後的輸出資料夾必須不存在。ZIP 與唯一外層資料夾同名，內附逐檔驗證清單。

`src/history.ts` 與 `scripts/flat_data.py` 共用固定 32 槽分片演算法。前端從根目錄讀取 market.json 與 history-XX.json。瀏覽器仍只對已開啟股票保存本機歷史快取；每日資料不進 Service Worker 的程式快取。

`SOURCE.zip` 不含 node_modules、dist、原始歷史行情與續傳快取；這些資料由外層公開快照及 PIPELINE_STATE.zip 還原。GitHub 每日流程會載入 market-data 分支持續保存的資料；不依賴 Actions 短期快取。

`FLAT_WORKFLOW.yml` 是扁平部署用範本。正式 repository 中放在 `.github/workflows/update-data.yml`。目前唯一發布工作同時處理手動發布、排程更新、歷史補建與 Pages 部署。

版本升級時更新 package.json/package-lock.json、src/pwa.ts、public/version.json、說明文件及工作流程範本。重新建置完整扁平包後，上傳 runtime 檔案及 SOURCE.zip，兩者須一致。

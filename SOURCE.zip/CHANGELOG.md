# 版本更新紀錄

## V1_1（1.1.0）— 2026-10-29

修正交付壓縮檔不完整、缺少結尾目錄而無法解壓的問題。新增完整關閉、落盤、驗證後才移至正式路徑的打包流程。ZIP 內含 RELEASE_MANIFEST.json，逐檔記錄大小與 SHA-256；另檢查 ZIP 結尾、CRC、路徑與清單。

更新檔案：package.json、package-lock.json、src/pwa.ts、public/version.json、scripts/build-docs.mjs、scripts/release_archive.py、tests/test_archive.py、README.md、SETUP.md／SETUP.html、CHANGELOG.md、TEST_REPORT.md，以及重新編譯的 dist/。

本次保留原有五頁介面、行情資料、篩選、技術圖表、分類、筆記、Drive 同步及每日排程。GitHub 部署仍需整份專案，包含 .github/workflows。

## V1_0（1.0.0）

首次版台股研究工作台。上一份下載 ZIP 已確認缺少完整結尾目錄，請改用 V1_1。

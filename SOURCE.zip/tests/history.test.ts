import test from 'node:test';
import assert from 'node:assert/strict';
import {execFileSync} from 'node:child_process';
import {historyFile} from '../src/history.ts';

test('browser shard routing matches the Python publisher for numeric and letter codes',()=>{
 const ids=['TWSE:2330','TPEX:00411A','TWSE:00632R',...Array.from({length:9000},(_,i)=>`TPEX:${1000+i}`)];
 const result=JSON.parse(execFileSync('python3',['-c',"import json,sys;sys.path.insert(0,'scripts');from flat_data import history_file;print(json.dumps([history_file(s) for s in json.load(sys.stdin)]))"],{input:JSON.stringify(ids),encoding:'utf8'}));
 assert.deepEqual(ids.map(historyFile),result);
 assert.equal(new Set(result).size,32);
});

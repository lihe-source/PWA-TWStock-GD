import json
from pathlib import Path
import sys
import tempfile
import unittest
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'scripts'))
from flat_data import pack, unpack, stage, history_file


class FlatTests(unittest.TestCase):
    def test_roundtrip_and_pages_inventory(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            project, flat, restored = root/'project', root/'flat', root/'restored'
            data = project/'public/data'
            (data/'history').mkdir(parents=True)
            snapshot = {'meta': {'date': '2026-10-28'}, 'stocks': [{'id': 'TWSE:2330'}]}
            bars = [['2026-10-28', 10, 12, 9, 11, 1500]]
            (data/'market.json').write_text(json.dumps(snapshot))
            for sid in ['TWSE:2330', 'TPEX:00411A', 'TWSE:00632R']:
                (data/'history'/f'{sid.replace(":", "-")}.json').write_text(json.dumps(bars))
            self.assertEqual(pack(project, flat), 3)
            self.assertEqual(len(list(flat.iterdir())), 33)
            self.assertTrue(all(p.is_file() for p in flat.iterdir()))
            self.assertEqual(unpack(flat, restored), 3)
            for original in data.rglob('*.json'):
                self.assertEqual(json.loads(original.read_text()), json.loads((restored/'public/data'/original.relative_to(data)).read_text()))
            (flat/'index.html').write_text('<html>site</html>')
            (flat/'SOURCE.zip').write_bytes(b'private staging exclusion test')
            (flat/'SITE_FILES.json').write_text(json.dumps(['index.html']))
            output = root/'pages'
            self.assertEqual(stage(flat, restored, output), 3)
            self.assertFalse((output/'SOURCE.zip').exists())
            self.assertTrue((output/'market.json').is_file())

    def test_wrong_shard_and_path_injection_are_rejected(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            (root/'market.json').write_text('{"meta":{"date":"2026-10-28"},"stocks":[{}]}')
            for n in range(32):
                (root/f'history-{n:02d}.json').write_text('{}')
            wrong = next(n for n in range(32) if f'history-{n:02d}.json' != history_file('TWSE:2330'))
            (root/f'history-{wrong:02d}.json').write_text('{"TWSE:2330":[]}')
            with self.assertRaises(ValueError):
                unpack(root, root/'result')
            (root/f'history-{wrong:02d}.json').write_text('{"TWSE:../../escape":[]}')
            with self.assertRaises(ValueError):
                unpack(root, root/'result')
            self.assertFalse((root/'result').exists())


if __name__ == '__main__':
    unittest.main()

import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import vm from 'node:vm';
import {execFileSync} from 'node:child_process';

test('service worker isolates project caches, excludes data and preserves offline help',async()=>{
 const temp=fs.mkdtempSync(path.join(os.tmpdir(),'twstock-sw-'));
 try{
  fs.mkdirSync(path.join(temp,'dist/data'),{recursive:true});
  for(const file of ['index.html','SETUP.html','version.json','data/market.json','market.json','history-00.json'])fs.writeFileSync(path.join(temp,'dist',file),'fixture');
  execFileSync(process.execPath,[path.resolve('scripts/build-sw.mjs')],{cwd:temp});
  const scope='https://example.test/stock/',prefix='twstock-shell-'+encodeURIComponent(scope)+'-';
  const handlers:Record<string,(event:any)=>void>={},removed:string[]=[],cached:string[]=[];
  let skipped=false;
  const caches={open:async()=>({addAll:async(files:string[])=>cached.push(...files)}),keys:async()=>[prefix+'old','twstock-shell-other-app'],delete:async(key:string)=>{removed.push(key)},match:async(key:any)=>String(key?.url||key).endsWith('SETUP.html')?'offline help':'offline index'};
  vm.runInNewContext(fs.readFileSync(path.join(temp,'dist/sw.js'),'utf8'),{URL,location:{origin:'https://example.test'},self:{registration:{scope},clients:{claim:async()=>{}},addEventListener:(name:string,fn:(e:any)=>void)=>handlers[name]=fn,skipWaiting:()=>{skipped=true}},caches,fetch:async()=>{throw new Error('offline')}});
  let pending:Promise<any>=Promise.resolve();
  handlers.install({waitUntil:(p:Promise<any>)=>pending=p});await pending;
  assert.deepEqual(cached.sort(),[scope+'SETUP.html',scope+'index.html'].sort());
  assert.equal(skipped,false,'installation must not interrupt unsaved edits');
  handlers.activate({waitUntil:(p:Promise<any>)=>pending=p});await pending;assert.deepEqual(removed,[prefix+'old']);
  let response:any;
  handlers.fetch({request:{url:scope+'SETUP.html',method:'GET',mode:'navigate'},respondWith:(p:Promise<any>)=>response=p});
  assert.equal(await response,'offline help');
  response=undefined;handlers.fetch({request:{url:scope+'data/market.json',method:'GET'},respondWith:()=>response=true});assert.equal(response,undefined);
  for(const file of ['market.json','history-00.json']){response=undefined;handlers.fetch({request:{url:scope+file+'?t=123',method:'GET'},respondWith:()=>response=true});assert.equal(response,undefined,'fresh flat data must bypass the shell cache')}
  handlers.message({data:{type:'SKIP_WAITING'}});assert.equal(skipped,true);
 }finally{fs.rmSync(temp,{recursive:true,force:true})}
});

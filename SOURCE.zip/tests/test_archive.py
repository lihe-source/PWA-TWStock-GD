import importlib.util
from pathlib import Path
import tempfile
import unittest
import zipfile

spec = importlib.util.spec_from_file_location('release_archive', Path(__file__).resolve().parents[1] / 'scripts/release_archive.py')
archive = importlib.util.module_from_spec(spec)
spec.loader.exec_module(archive)


class ArchiveTests(unittest.TestCase):
    def test_archive_roundtrip_keeps_workflows_and_rejects_truncation(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp, 'PWA-TWStock-GD-V1_1')
            (root / '.github/workflows').mkdir(parents=True)
            (root / 'node_modules').mkdir()
            (root / 'node_modules/excluded.txt').write_text('not shipped')
            (root / '.github/workflows/pages.yml').write_text('jobs: {}')
            (root / 'README.md').write_text('完整程式', encoding='utf-8')
            target = root.with_suffix('.zip')
            built = archive.build_archive(root, target)
            self.assertEqual(built, archive.verify_archive(target))
            with zipfile.ZipFile(target) as z:
                self.assertIn(root.name + '/.github/workflows/pages.yml', z.namelist())
                self.assertFalse(any('node_modules' in n for n in z.namelist()))
                out = Path(temp, 'unpacked')
                z.extractall(out)
                self.assertEqual((out / root.name / 'README.md').read_text(encoding='utf-8'), '完整程式')
            target.write_bytes(target.read_bytes()[:-50])
            with self.assertRaisesRegex(ValueError, '結尾'):
                archive.verify_archive(target)

    def test_manifest_detects_valid_zip_with_modified_contents(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp, 'app')
            root.mkdir()
            (root / 'index.html').write_text('original')
            target = root.with_suffix('.zip')
            archive.build_archive(root, target)
            with zipfile.ZipFile(target) as z:
                files = {n: z.read(n) for n in z.namelist()}
            files['app/index.html'] = b'changed'
            with zipfile.ZipFile(target, 'w') as z:
                for name, body in files.items():
                    z.writestr(name, body)
            with self.assertRaisesRegex(ValueError, '校驗失敗'):
                archive.verify_archive(target)


if __name__ == '__main__':
    unittest.main()

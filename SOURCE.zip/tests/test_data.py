import sys,unittest,datetime as dt
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
from update_data import date,number,period,normalize_quote,historical,flow_rows,margin_rows,closure_dates
from indicators import series,latest

class NormalizationTests(unittest.TestCase):
    def test_dates(self):
        for v in ['1151028','20261028','115/10/28','2026/10/28','115年10月28日','2026-10-28']:
            self.assertEqual(date(v),'2026-10-28',v)
        self.assertEqual(date('1150230'),'');self.assertEqual(period('11509'),'2026-09')
    def test_missing_not_zero(self):
        for v in ['',None,'--','除息','NaN','N/A']:
            self.assertIsNone(number(v))
        self.assertEqual(number('0'),0);self.assertEqual(number('-1,234.50'),-1234.5)
    def test_quote_reference_return_and_units(self):
        r={'Date':'1151028','Code':'2330','Name':'台積電','OpeningPrice':'100','HighestPrice':'103','LowestPrice':'99','ClosingPrice':'102','TradeVolume':'123,000','TradeValue':'12,500,000','Change':'2'}
        s=normalize_quote(r,'TWSE',{'2330':{'industry':'半導體業'}})
        self.assertEqual(s['pct'],2);self.assertEqual(s['volume'],123000);self.assertEqual(s['date'],'2026-10-28')
        r['LowestPrice']='104'
        with self.assertRaises(ValueError):normalize_quote(r,'TWSE',{'2330':{}})
    def test_universe_excludes_warrants_and_foreign_currency(self):
        base={'Date':'1151028','OpeningPrice':'1','HighestPrice':'1','LowestPrice':'1','ClosingPrice':'1','TradeVolume':'1000','TradeValue':'1000','Change':'0'}
        self.assertIsNone(normalize_quote({**base,'Code':'030001','Name':'認購權證'},'TWSE',{}))
        self.assertIsNone(normalize_quote({**base,'Code':'00687U','Name':'美元級別'},'TWSE',{}))
        self.assertEqual(normalize_quote({**base,'Code':'0050','Name':'元大台灣50'},'TWSE',{})['type'],'etf')
    def test_history_date_and_negative_sign(self):
        r=['2330','台積電','1,000','50','10,000','10','11','9','9.5','<p style=color:green>-</p>','0.5']
        payload={'date':'20261028','stat':'OK','tables':[{'fields':['證券代號','開盤價','成交股數'],'data':[r]*100}]}
        b=historical(payload,'TWSE','2026-10-28')['2330']
        self.assertEqual(b[6],10);self.assertEqual(b[5],1000)
        with self.assertRaises(ValueError):historical(payload,'TWSE','2026-10-27')
    def test_tpex_volume_scope(self):
        r=['1240','茂生農經','54','+1','53','55','52','7,174,000','73034400','800','54']
        p={'date':'20261028','stat':'ok','tables':[{'fields':['代號','收盤 ','成交股數  '],'data':[r]*100,'totalCount':100}]}
        b=historical(p,'TPEX','2026-10-28')['1240'];self.assertEqual(b[5],7174000);self.assertEqual(b[6],53)
    def test_margin_is_balance_difference(self):
        r=['2330','台積電','10','5','1','100','104','1000','1','2','0','20','21','1000','0','']
        p={'date':'20261028','stat':'OK','tables':[{'fields':['代號','名稱']+['x']*12+['資券互抵','註記'],'data':[r]}]}
        x=margin_rows(p,'2026-10-28')['2330'];self.assertEqual(x['marginChange'],4);self.assertEqual(x['shortChange'],1)
    def test_calendar_does_not_mark_opening_as_holiday(self):
        rows=[{'Date':'1150101','Name':'元旦','Description':'放假1日'},{'Date':'1150102','Name':'開始交易日','Description':''},{'Date':'1150212','Name':'休市','Description':'僅辦理結算交割'}]
        self.assertEqual(closure_dates(rows),{'2026-01-01','2026-02-12'})

class IndicatorTests(unittest.TestCase):
    def bars(self,n=260):
        return [[(dt.date(2025,1,1)+dt.timedelta(days=i)).isoformat(),100+i,102+i,99+i,101+i,1000,100+i] for i in range(n)]
    def test_warmup(self):
        s=series(self.bars(30));self.assertIsNone(s['ma20'][18]);self.assertIsNotNone(s['ma20'][19]);self.assertIsNone(s['rsi'][13]);self.assertEqual(s['rsi'][14],100);self.assertIsNone(s['hist'][29])
    def test_volume_excludes_current_day(self):
        b=self.bars(30);b[-1][5]=2000;m,_=latest(b);self.assertEqual(m['volumeRatio'],2)
    def test_event_gates_unsafe_cross_period_signal(self):
        b=self.bars(260);b[-1][6]=200;m,event=latest(b);self.assertEqual(event,b[-1][0]);self.assertIsNone(m['above20']);self.assertIsNone(m['hist'])
    def test_flat_prices_rsi_kd_are_defined(self):
        b=[[f'2026-01-{i+1:02d}',100,100,100,100,1000,100] for i in range(25)]
        s=series(b);self.assertEqual(s['rsi'][-1],50);self.assertAlmostEqual(s['k'][-1],50)

if __name__=='__main__':unittest.main()

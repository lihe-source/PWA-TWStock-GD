"""Raw-price indicators. Formulas are mirrored by src/indicators.ts; no paid API."""
import math

FORMULA_VERSION = '1.0.0'

def sma(a, n):
    return [None if i < n-1 or None in a[i-n+1:i+1] else sum(a[i-n+1:i+1])/n for i in range(len(a))]

def ema(a, n):
    result, prev = [], None
    for i, value in enumerate(a):
        if value is None:
            prev = None
        elif prev is None:
            part = a[max(0,i-n+1):i+1]
            if len(part) == n and None not in part:
                prev = sum(part)/n
        else:
            prev = value*2/(n+1)+prev*(1-2/(n+1))
        result.append(prev)
    return result

def series(bars):
    c = [b[4] for b in bars]
    result = {'ma'+str(n):sma(c,n) for n in (5,10,20,60,120,240)}
    e12,e26 = ema(c,12),ema(c,26)
    dif = [None if a is None or b is None else a-b for a,b in zip(e12,e26)]
    dea = ema(dif,9)
    result.update(dif=dif,dea=dea,hist=[None if a is None or b is None else a-b for a,b in zip(dif,dea)])
    k,d,gain,loss,count = 50.0,50.0,0.0,0.0,0
    ks,ds,rsi = [],[],[None]*len(c)
    for i,b in enumerate(bars):
        q=bars[max(0,i-8):i+1]
        if len(q)==9 and all(x[2] is not None and x[3] is not None for x in q) and c[i] is not None:
            hi,lo=max(x[2] for x in q),min(x[3] for x in q)
            rsv=50 if hi==lo else 100*(c[i]-lo)/(hi-lo)
            k=k*2/3+rsv/3;d=d*2/3+k/3;ks.append(k);ds.append(d)
        else:
            ks.append(None);ds.append(None)
        if i==0:
            continue
        if c[i] is None or c[i-1] is None:
            gain=loss=0;count=0;continue
        delta=c[i]-c[i-1]
        if count<14:
            gain+=max(0,delta);loss+=max(0,-delta);count+=1
            if count==14:
                gain/=14;loss/=14
        else:
            gain=(gain*13+max(0,delta))/14;loss=(loss*13+max(0,-delta))/14
        if count>=14:
            rsi[i]=50 if gain==loss==0 else 100 if loss==0 else 100-100/(1+gain/loss)
    result.update(k=ks,d=ds,rsi=rsi)
    std=[None if result['ma20'][i] is None else math.sqrt(sum((x-result['ma20'][i])**2 for x in c[i-19:i+1])/20) for i in range(len(c))]
    result['upper']=[None if x is None else x+2*std[i] for i,x in enumerate(result['ma20'])]
    result['lower']=[None if x is None else x-2*std[i] for i,x in enumerate(result['ma20'])]
    return result

def latest(bars, event_dates=()):
    if not bars:
        return {},None
    s=series(bars);m={k:vals[-1] for k,vals in s.items()}
    close=bars[-1][4]
    m['above20']=None if m['ma20'] is None or close is None else int(close>m['ma20'])
    m['bullish']=None if any(m[k] is None for k in ('ma5','ma20','ma60')) else int(m['ma5']>m['ma20']>m['ma60'])
    m['golden']=None if len(bars)<21 or s['ma5'][-2] is None or s['ma20'][-2] is None or m['ma5'] is None or m['ma20'] is None else int(s['ma5'][-2]<=s['ma20'][-2] and m['ma5']>m['ma20'])
    past=bars[-21:-1]
    m['volumeRatio']=None if len(past)<20 or sum(b[5] for b in past)==0 else bars[-1][5]/(sum(b[5] for b in past)/20)
    m['break20']=None if len(past)<20 or close is None or any(b[2] is None for b in past) else int(close>max(b[2] for b in past))
    # Reference close vs previous actual close detects ex events without inventing adjusted prices.
    event_index=[]
    for i,b in enumerate(bars):
        if b[0] in event_dates:
            event_index.append(i)
        if i and len(b)>6 and b[6] is not None and bars[i-1][4] is not None:
            if abs(b[6]-bars[i-1][4])>max(0.011,bars[i-1][4]*0.001):
                event_index.append(i)
    last_event=max(event_index) if event_index else None
    if last_event is not None:
        distance=len(bars)-1-last_event
        for key,n in {'ma5':5,'ma10':10,'ma20':20,'ma60':60,'ma120':120,'ma240':240,'above20':20,'bullish':60,'golden':21,'break20':21,'k':60,'d':60,'rsi':80,'dif':130,'dea':160,'hist':160,'upper':20,'lower':20,'volumeRatio':21}.items():
            if distance<n:
                m[key]=None
    return {k:round(v,6) if isinstance(v,float) and math.isfinite(v) else v for k,v in m.items()},bars[last_event][0] if last_event is not None else None

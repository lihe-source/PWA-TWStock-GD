"""Create a phone-uploadable flat directory and verified outer ZIP."""
from pathlib import Path
import argparse
import html
import json
import os
import shutil
import zipfile
from release_archive import build_archive

ROOT = Path(__file__).resolve().parents[1]


def make(output):
    output = Path(output).resolve()
    if output.exists():
        raise ValueError('Choose a new output directory; existing releases are never removed')
    dist = ROOT/'dist'
    if any(p.is_dir() for p in dist.iterdir()):
        raise ValueError('Build output is not flat')
    shutil.copytree(dist, output)
    workflow = (ROOT/'FLAT_WORKFLOW.yml').read_text(encoding='utf-8')
    (output/'update-data.workflow.yml').write_text(workflow, encoding='utf-8')
    mobile = '''<!doctype html><html lang="zh-Hant"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>股序｜手機設定工作流程</title><style>body{max-width:800px;margin:32px auto;padding:0 18px;background:#f4f5f1;color:#233c31;font:16px/1.8 system-ui}button{font:inherit;background:#274e3d;color:white;border:0;border-radius:8px;padding:14px;cursor:pointer}textarea{box-sizing:border-box;width:100%;height:56vh;font:12px/1.5 monospace;margin-top:20px;padding:14px;border:1px solid #aab9ae;border-radius:8px}code{overflow-wrap:anywhere}a{color:#285e45}#status{min-height:28px}</style><h1>手機設定每日更新</h1><p>先複製下方完整內容，再到 GitHub 的 Code → Add file → Create new file。</p><p>檔名：<code>.github/workflows/update-data.yml</code></p><p>Pages Source 必須改成 GitHub Actions。完整步驟與 Google Drive 設定請見 <a href="SETUP.html">設定說明</a>。</p><button id="copy">複製完整工作流程</button><p id="status" role="status"></p><textarea id="yaml" readonly aria-label="完整 GitHub 工作流程">'''+html.escape(workflow)+'''</textarea><script>document.getElementById('copy').onclick=async()=>{const t=document.getElementById('yaml'),s=document.getElementById('status');try{if(!navigator.clipboard)throw new Error();await navigator.clipboard.writeText(t.value);s.textContent='已複製。請到 GitHub 建立指定路徑的檔案並貼上。'}catch{t.focus();t.select();t.setSelectionRange(0,t.value.length);s.textContent='已選取全文；請使用手機的「複製」功能。'}};</script></html>'''
    (output/'MOBILE.html').write_text(mobile, encoding='utf-8')
    site_files = sorted([p.name for p in dist.iterdir() if p.name != 'market.json' and not p.name.startswith('history-')] + ['MOBILE.html'])
    (output/'SITE_FILES.json').write_text(json.dumps(site_files, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
    for name in ['SETUP.md','LICENSE','DATA_SOURCES.md','TEST_REPORT.md']:
        shutil.copy2(ROOT/name, output/name)
    (output/'README.md').write_text('''# 股序 V1_2｜手機扁平版

五頁台股研究 PWA：首頁、篩選、技術分析、分類與設定。版本 1.2.0。

1. 將本資料夾裡的全部檔案直接上傳 GitHub repository 根目錄。不要只上傳外層 ZIP。
2. Settings → Pages → Deploy from a branch → main → /(root)，先發布網站。
3. 開啟網站的 MOBILE.html，複製工作流程，依 SETUP.html 在 GitHub 建立 `.github/workflows/update-data.yml`，再改用 GitHub Actions 發布與自動更新。

詳見 [完整設定說明](SETUP.md)。不需要手機安裝 Node、Python 或 Git。

SOURCE.zip 是完整可編輯原始碼；PIPELINE_STATE.zip 是公開來源快取與續傳狀態。兩個檔案保持 ZIP 格式一起上傳，不用再解壓。它們由 GitHub Actions 還原使用。

market.json 與 32 個 history-XX.json 是初始公開行情；不是即時報價。後續行情會保存在 market-data 分支並由 Actions 直接部署。私人分類與筆記留在本機，選擇啟用後同步到你的 Google Drive。

若沿用舊版專案，先停用舊資料與發布工作，避免覆寫本版。工作流程必須位於 `.github/workflows/`，根目錄的 update-data.workflow.yml 只是供手機複製的範本。

ZIP 已附 RELEASE_MANIFEST.json 逐檔雜湊，可使用 SOURCE.zip 中的 scripts/release_archive.py 驗證完整性。
''', encoding='utf-8')
    excluded = {'node_modules','dist','data-store','.git','.github','.openai','.sites-runtime','__pycache__','test-results','.market-store'}
    with zipfile.ZipFile(output/'SOURCE.zip','w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for directory, subdirs, files in os.walk(ROOT):
            subdirs[:] = sorted(d for d in subdirs if d not in excluded and not Path(directory,d).is_symlink())
            if Path(directory) == ROOT/'public':
                subdirs[:] = [d for d in subdirs if d != 'data']
            for name in sorted(files):
                path = Path(directory,name)
                rel = path.relative_to(ROOT)
                if path.is_symlink() or name.startswith(('.env','__qa-')) or name.endswith(('.pyc','.tsbuildinfo','.zip','.tmp')):
                    continue
                if rel.parent == Path('public') and (name=='market.json' or name.startswith('history-')):
                    continue
                z.write(path,rel.as_posix())
    with zipfile.ZipFile(output/'PIPELINE_STATE.zip','w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for path in sorted((ROOT/'data-store').rglob('*.json')):
            z.write(path,path.relative_to(ROOT).as_posix())
    files = list(output.iterdir())
    if len(files)+1 > 100 or any(not p.is_file() or p.stat().st_size > 25*1024**2 for p in files):
        raise ValueError('Exceeded mobile upload budget (100 files / 25 MiB each)')
    result = build_archive(output, output.with_suffix('.zip'))
    print(json.dumps(result,ensure_ascii=False))


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('output',type=Path)
    make(p.parse_args().output)

import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
const walk=(p)=>fs.readdirSync(p,{withFileTypes:true}).flatMap(e=>e.isDirectory()?walk(path.join(p,e.name)):[path.join(p,e.name)]);
const files=walk('dist').filter(p=>!p.includes('/data/')&&!/\/(market|history-\d{2})\.json$/.test(p)&&!p.endsWith('sw.js')&&!p.endsWith('version.json')).map(p=>p.slice(5));
const hash=crypto.createHash('sha256');for(const f of files)hash.update(fs.readFileSync('dist/'+f));const id=hash.digest('hex').slice(0,14);
fs.writeFileSync('dist/sw.js',`const PREFIX='twstock-shell-'+encodeURIComponent(self.registration.scope)+'-';const CACHE=PREFIX+'${id}';const FILES=${JSON.stringify(files)};
self.addEventListener('install',e=>e.waitUntil(caches.open(CACHE).then(c=>c.addAll(FILES.map(f=>new URL(f,self.registration.scope).href)))));
self.addEventListener('activate',e=>e.waitUntil((async()=>{for(const k of await caches.keys())if(k.startsWith(PREFIX)&&k!==CACHE)await caches.delete(k);await self.clients.claim()})()));
self.addEventListener('message',e=>{if(e.data?.type==='SKIP_WAITING')self.skipWaiting()});
self.addEventListener('fetch',e=>{const u=new URL(e.request.url);if(e.request.method!=='GET'||u.origin!==location.origin||u.pathname.includes('/data/')||/\\/(market|history-\\d{2})\\.json$/.test(u.pathname)||u.pathname.endsWith('version.json')||u.pathname.endsWith('sw.js'))return;
if(e.request.mode==='navigate'){e.respondWith(fetch(e.request).catch(async()=>(await caches.match(e.request))||caches.match(new URL('index.html',self.registration.scope).href)));return}
e.respondWith(caches.open(CACHE).then(async c=>(await c.match(e.request))||fetch(e.request)));});`);
console.log('Service worker generated:',id,files.length,'shell files');

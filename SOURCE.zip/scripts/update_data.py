#!/usr/bin/env python3
"""Official TWSE/TPEx daily data pipeline. Python 3.11+, standard library only.
No API credentials. Never replaces a valid source with a failed/empty response.
History uses one bulk request per market/date; blocks are respected, not bypassed.
"""
from __future__ import annotations
import argparse,datetime as dt,html,json,math,os,re,sys,time,urllib.request,urllib.error
from pathlib import Path
from zoneinfo import ZoneInfo
from indicators import latest,FORMULA_VERSION

ROOT=Path(__file__).resolve().parent.parent
OUT=ROOT/'public'/'data';STORE=ROOT/'data-store';RAW=STORE/'sources'
TZ=ZoneInfo('Asia/Taipei')
INDUSTRIES={'01':'水泥工業','02':'食品工業','03':'塑膠工業','04':'紡織纖維','05':'電機機械','06':'電器電纜','07':'化學生技醫療','08':'玻璃陶瓷','09':'造紙工業','10':'鋼鐵工業','11':'橡膠工業','12':'汽車工業','14':'建材營造','15':'航運業','16':'觀光餐旅','17':'金融保險','18':'貿易百貨','19':'綜合','20':'其他','21':'化學工業','22':'生技醫療','23':'油電燃氣','24':'半導體業','25':'電腦及週邊設備','26':'光電業','27':'通信網路業','28':'電子零組件業','29':'電子通路業','30':'資訊服務業','31':'其他電子業','32':'文化創意業','33':'農業科技','34':'電子商務','35':'綠能環保','36':'數位雲端','37':'運動休閒','38':'居家生活'}
TW='https://openapi.twse.com.tw/v1';OT='https://www.tpex.org.tw/openapi/v1'
API={
 'tw_master':('上市公司基本資料',TW+'/opendata/t187ap03_L',500),
 'ot_master':('上櫃公司基本資料',OT+'/mopsfin_t187ap03_O',400),
 'tw_quotes':('上市日行情',TW+'/exchangeReport/STOCK_DAY_ALL',500),
 'ot_quotes':('上櫃日行情（不含定價）',OT+'/tpex_mainboard_quotes',400),
 'tw_value':('上市本益比／殖利率',TW+'/exchangeReport/BWIBBU_d',400),
 'ot_value':('上櫃本益比／殖利率',OT+'/tpex_mainboard_peratio_analysis',300),
 'tw_revenue':('上市月營收',TW+'/opendata/t187ap05_L',400),
 'ot_revenue':('上櫃月營收',OT+'/mopsfin_t187ap05_O',300),
 'tw_eps':('上市本期累計 EPS',TW+'/opendata/t187ap14_L',400),
 'ot_eps':('上櫃本期累計 EPS',OT+'/mopsfin_t187ap14_O',300),
 'ot_flow':('上櫃三大法人',OT+'/tpex_3insti_daily_trading',300),
 'ot_margin':('上櫃融資融券',OT+'/tpex_mainboard_margin_balance',300),
 'tw_index':('加權指數',TW+'/exchangeReport/MI_INDEX',1),
 'ot_index':('櫃買指數',OT+'/tpex_index',1),
 'calendar':('官方開休市行事曆',TW+'/holidaySchedule/holidaySchedule',1),
 'tw_events':('上市除權息預告',TW+'/exchangeReport/TWT48U_ALL',0),
 'ot_events':('上櫃除權息預告',OT+'/tpex_exright_prepost',0),
}

def clean(v):return re.sub(r'<[^>]*>','',html.unescape(str(v or ''))).strip()
def number(v):
    if isinstance(v,(int,float)) and math.isfinite(v):return v
    s=clean(v).replace(',','').replace('−','-').replace('%','')
    if not re.fullmatch(r'[+-]?(?:\d+(?:\.\d*)?|\.\d+)',s):return None
    v=float(s)
    return int(v) if v.is_integer() else v

def date(v):
    s=clean(v)
    if not s:return ''
    if re.fullmatch(r'\d{4}-\d{2}-\d{2}',s):parts=s.split('-')
    elif re.search(r'[/年月日]',s):parts=[x for x in re.split(r'\D+',s) if x]
    elif len(s)==8:parts=[s[:4],s[4:6],s[6:]]
    elif len(s)==7:parts=[s[:3],s[3:5],s[5:]]
    else:return ''
    if len(parts)<3:return ''
    y,m,d=map(int,parts[:3]);y=y+1911 if y<1911 else y
    try:return dt.date(y,m,d).isoformat()
    except ValueError:return ''

def period(v):
    s=clean(v)
    if len(s)==5 and s.isdigit():return f'{int(s[:3])+1911}-{s[3:]}'
    if len(s)==6 and s.isdigit():return s[:4]+'-'+s[4:]
    return s

def load(path,default):
    try:return json.loads(path.read_text(encoding='utf-8'))
    except (OSError,json.JSONDecodeError):return default

def save(path,value):
    path.parent.mkdir(parents=True,exist_ok=True)
    tmp=path.with_suffix(path.suffix+'.tmp')
    tmp.write_text(json.dumps(value,ensure_ascii=False,separators=(',',':'),allow_nan=False),encoding='utf-8')
    tmp.replace(path)

class Blocked(Exception):pass
class Fetcher:
    def __init__(self,delay=1.5):self.delay=delay;self.last=0;self.blocked_hosts=set()
    def get(self,url):
        host=urllib.parse.urlparse(url).netloc
        if host in self.blocked_hosts:raise Blocked('來源暫時拒絕存取，本輪停止重試此主機')
        for attempt in range(3):
            time.sleep(max(0,self.delay-(time.monotonic()-self.last)))
            try:
                req=urllib.request.Request(url,headers={'User-Agent':'TaiwanStockResearch/1.0 (personal open-data research)','Accept':'application/json'})
                self.last=time.monotonic()
                with urllib.request.urlopen(req,timeout=35) as r:
                    if r.status!=200:raise ValueError(f'HTTP {r.status}')
                    data=r.read(30_000_001)
                    if len(data)>30_000_000:raise ValueError('來源檔案超過大小限制')
                    return json.loads(data.decode('utf-8-sig'))
            except urllib.error.HTTPError as e:
                if e.code in (301,302,303,307,308,401,403):
                    self.blocked_hosts.add(host);raise Blocked(f'HTTP {e.code}，保留資料並停止本輪該主機擷取') from e
                if e.code not in (429,500,502,503,504) or attempt==2:raise
                retry=e.headers.get('Retry-After','')
                time.sleep(min(30,int(retry)) if retry.isdigit() else 2**(attempt+1))
            except (OSError,ValueError) as e:
                if attempt==2:raise
                time.sleep(2**(attempt+1))
        raise ValueError('資料下載失敗')

def row_date(rows):
    dates=[date(r.get('Date') or r.get('日期') or r.get('出表日期')) for r in rows if isinstance(r,dict)]
    return max((d for d in dates if d),default='')

def normalize_quote(r,market,master):
    code=clean(r.get('Code') if market=='TWSE' else r.get('SecuritiesCompanyCode'))
    name=clean(r.get('Name') if market=='TWSE' else r.get('CompanyName'))
    if not re.fullmatch(r'[0-9A-Z]{4,8}',code):return None
    if code in master and re.fullmatch(r'\d{4}',code):kind='stock'
    elif re.fullmatch(r'00\d{2,4}[A-Z]?',code) and not code.endswith('U') and not re.search(r'\+.*[Uu]$',name):kind='etf'
    else:return None
    keys=['OpeningPrice','HighestPrice','LowestPrice','ClosingPrice','TradeVolume','TradeValue'] if market=='TWSE' else ['Open','High','Low','Close','TradingShares','TransactionAmount']
    o,h,l,c,vol,amount=[number(r.get(k)) for k in keys]
    # zero OHLC is not a tradable bar. Never silently turn missing price into 0.
    o,h,l,c=[v if v is not None and v>0 else None for v in (o,h,l,c)]
    if c is not None and all(x is not None for x in (o,h,l)) and not l<=min(o,c)<=max(o,c)<=h:raise ValueError(f'{code} 開高低收不一致')
    change=number(r.get('Change'));ref=c-change if c is not None and change is not None else None
    pct=change/ref*100 if ref and ref>0 else None
    return {'id':market+':'+code,'code':code,'name':name,'market':market,'industry':master.get(code,{}).get('industry','ETF' if kind=='etf' else '其他'),'type':kind,'date':date(r.get('Date')),'open':o,'high':h,'low':l,'close':c,'change':change,'pct':round(pct,4) if pct is not None else None,'volume':vol or 0,'amount':amount or 0,'pe':None,'pb':None,'yield':None,'metrics':{},'historyCount':0}

def table_rows(payload,required):
    if not isinstance(payload,dict):raise ValueError('預期官方表格物件')
    if clean(payload.get('stat','')).lower()!='ok':raise ValueError('官方報表尚無可用資料：'+clean(payload.get('stat'))[:100])
    for table in payload.get('tables',[]):
        fs=[clean(x).replace(' ','') for x in table.get('fields',[])]
        if all(any(req in f for f in fs) for req in required):
            rows=table.get('data',[])
            if not rows:raise ValueError('表格沒有資料')
            if table.get('totalCount') and int(table['totalCount'])!=len(rows):raise ValueError('官方表格分頁未完整')
            return fs,rows
    raise ValueError('官方資料欄位改變，找不到指定表格')

def historical(payload,market,expected):
    actual=date(payload.get('date')) if isinstance(payload,dict) else ''
    if actual!=expected:raise ValueError(f'回傳日期 {actual or "未知"} 不是要求的 {expected}')
    fields,rows=table_rows(payload,['證券代號','開盤價','成交股數'] if market=='TWSE' else ['代號','收盤','成交股數'])
    if len(rows)<100:raise ValueError('歷史全市場筆數過少，未接受此日')
    out={}
    for r in rows:
        if len(r)<11:raise ValueError('歷史欄位數不足')
        code=clean(r[0]);
        if not re.fullmatch(r'[0-9A-Z]{4,8}',code):continue
        if market=='TWSE':
            o,h,l,c=[number(r[i]) for i in (5,6,7,8)];v=number(r[2]);change=number(r[10]);sign=clean(r[9]);change=(-abs(change) if '-' in sign else abs(change)) if change is not None and sign in ('+','-','') else None
        else:o,h,l,c=[number(r[i]) for i in (4,5,6,2)];v=number(r[7]);change=number(r[3])
        if c is None or c<=0 or v is None or v<=0:continue
        if any(x is None or x<=0 for x in (o,h,l)):continue
        if not l<=min(o,c)<=max(o,c)<=h:raise ValueError(f'{code} 歷史價位不一致')
        out[code]=[expected,o,h,l,c,v,c-change if change is not None else None]
    return out

def margin_rows(payload,expected):
    if date(payload.get('date'))!=expected:raise ValueError('融資券日期不符')
    fields,rows=table_rows(payload,['代號','資券互抵'])
    if len(fields)<16:raise ValueError('融資券欄位變更')
    return {clean(r[0]):{'marginChange':number(r[6])-number(r[5]) if number(r[6]) is not None and number(r[5]) is not None else None,'shortChange':number(r[12])-number(r[11]) if number(r[12]) is not None and number(r[11]) is not None else None,'marginDate':expected} for r in rows if len(r)>=16}

def flow_rows(payload,expected):
    if date(payload.get('date'))!=expected or clean(payload.get('stat')).lower()!='ok':raise ValueError('法人日期或狀態不符')
    fs=payload.get('fields',[]);rows=payload.get('data',[])
    if len(fs)<19 or '外陸資買賣超' not in fs[4] or '投信買賣超' not in fs[10] or len(rows)<300:raise ValueError('法人欄位變更或筆數不足')
    return {clean(r[0]):{'foreign':number(r[4]),'trust':number(r[10]),'dealer':number(r[11]),'institutionDate':expected} for r in rows if len(r)>=19}

def closure_dates(rows):
    result=set()
    for r in rows:
        text=clean(r.get('Name'))+' '+clean(r.get('Description'))
        if any(s in text for s in ('開始交易','恢復交易','最後交易','交易開始')):continue
        if any(s in text for s in ('放假','補假','休市','無交易','不交易','僅辦理結算交割')):
            d=date(r.get('Date'))
            if d:result.add(d)
    return result

class Pipeline:
    def __init__(self,args):
        self.args=args;self.fetch=Fetcher(args.delay);self.sources={};self.rows={};self.warnings=[]
        self.old=load(OUT/'market.json',{});self.state=load(STORE/'state.json',{'days':{},'events':{},'flow':{}})
        self.now=dt.datetime.now(TZ);self.nowtext=self.now.isoformat(timespec='seconds')
        self.history={};self.modified=set()
    def source(self,key,name,url,minimum=0,validator=None,ttl=0):
        cache=RAW/(key+'.json');prev=load(cache,{})
        try:
            if prev and (self.args.cached or (ttl and time.time()-prev.get('fetchedEpoch',0)<ttl)):
                value=prev['data'];fetched=prev['fetchedAt']
            else:
                if self.args.cached:raise ValueError('離線重建：尚無來源快取')
                value=self.fetch.get(url)
                if validator:validator(value)
                elif not isinstance(value,list) or len(value)<minimum or (value and not isinstance(value[0],dict)):raise ValueError('資料型態／筆數不符')
                if isinstance(value,list) and prev.get('data') and len(value)<len(prev['data'])*0.75 and minimum>0:raise ValueError('資料筆數異常減少，保留上次結果')
                fetched=self.nowtext;save(cache,{'data':value,'fetchedAt':fetched,'fetchedEpoch':time.time()})
            rd=row_date(value) if isinstance(value,list) else date(value.get('date'))
            count=len(value) if isinstance(value,list) else len(validator(value)) if validator else len(value.get('data',[]))
            self.sources[key]={'name':name,'url':url,'ok':True,'date':rd,'count':count,'fetchedAt':fetched}
            self.rows[key]=value;return value
        except Exception as e:
            value=prev.get('data',[] if validator is None else {})
            self.sources[key]={'name':name,'url':url,'ok':False,'date':row_date(value) if isinstance(value,list) else date(value.get('date')),'count':len(value) if isinstance(value,list) else 0,'error':str(e)[:200],'fetchedAt':prev.get('fetchedAt','')}
            self.rows[key]=value;print(f'WARNING {name}: {e}',flush=True);return value
    def get_history(self,key):
        if key not in self.history:self.history[key]={b[0]:b for b in load(OUT/'history'/(key.replace(':','-')+'.json'),[])}
        return self.history[key]
    def put_bar(self,key,bar):
        h=self.get_history(key)
        if h.get(bar[0])!=bar:h[bar[0]]=bar;self.modified.add(key)
    def flush(self):
        for key in self.modified:
            h=self.history[key];save(OUT/'history'/(key.replace(':','-')+'.json'),[h[d] for d in sorted(h)])
        self.modified.clear();save(STORE/'state.json',self.state)
    def run(self):
        RAW.mkdir(parents=True,exist_ok=True)
        for key,(name,url,minrows) in API.items():
            ttl=3600*8 if any(x in key for x in ('master','revenue','eps','calendar','events')) else 0
            self.source(key,name,url,minrows,ttl=ttl)
        masters={}
        for market,prefix in [('TWSE','tw'),('TPEX','ot')]:
            master={}
            for r in self.rows[prefix+'_master']:
                code=clean(r.get('公司代號') if market=='TWSE' else r.get('SecuritiesCompanyCode'))
                ind=clean(r.get('產業別') if market=='TWSE' else r.get('SecuritiesIndustryCode'))
                master[code]={'industry':INDUSTRIES.get(ind.zfill(2),ind or '其他'),'name':clean(r.get('公司簡稱') if market=='TWSE' else r.get('CompanyAbbreviation'))}
            masters[market]=master
        stocks=[]
        for market,prefix in [('TWSE','tw'),('TPEX','ot')]:
            if not masters[market]:
                self.warnings.append(market+' 公司名單未取得，保留舊市場資料')
                stocks.extend(s for s in self.old.get('stocks',[]) if s['market']==market);continue
            candidates=[]
            try:
                for r in self.rows[prefix+'_quotes']:
                    s=normalize_quote(r,market,masters[market])
                    if s and s['date']:candidates.append(s)
            except ValueError as e:
                self.warnings.append(str(e));candidates=[]
            if len(candidates)<300:
                stocks.extend(s for s in self.old.get('stocks',[]) if s['market']==market);continue
            stocks.extend(candidates)
        if not stocks:raise RuntimeError('未取得可用市場行情；未發布空白資料。稍後重新執行工作。')
        stockmap={s['id']:s for s in stocks};latest_date=max(s['date'] for s in stocks if s['date'])
        closed=closure_dates(self.rows['calendar']);save(STORE/'calendar.json',sorted(set(load(STORE/'calendar.json',[]))|closed))
        d=self.now.date()
        if self.now.hour<14:d-=dt.timedelta(days=1)
        while d.weekday()>=5 or d.isoformat() in closed:d-=dt.timedelta(days=1)
        expected=d.isoformat()
        market_dates={m:max((s['date'] for s in stocks if s['market']==m),default='') for m in ('TWSE','TPEX')}
        for market,day in market_dates.items():
            if day<expected:self.warnings.append(f'{market} 行情目前為 {day or "未取得"}，預期交易日 {expected} 尚未到齊。')
        if len(set(market_dates.values()))>1:self.warnings.append('上市與上櫃行情日不同；預設篩選與首頁統計只採最新行情日。')
        if latest_date<expected:self.warnings.append(f'官方行情目前為 {latest_date}；預期交易日 {expected} 尚未到齊（臨時休市亦可能影響）。')
        self.fill_extras(stockmap)
        for s in stocks:
            if s['close'] is not None and s['volume']>0 and all(s[k] is not None for k in ('open','high','low')):
                ref=s['close']-s['change'] if s['change'] is not None else None
                self.put_bar(s['id'],[s['date'],s['open'],s['high'],s['low'],s['close'],s['volume'],ref])
        for market,prefix in [('TWSE','tw'),('TPEX','ot')]:
            dates={s['date'] for s in stocks if s['market']==market}
            for d in dates:
                if self.sources[prefix+'_quotes']['ok']:
                    self.state['days'][market+':'+d]={'status':'ok','at':self.nowtext}
        self.flush()
        self.backfill(set(stockmap),latest_date,closed)
        for s in stocks:
            bars=sorted(self.get_history(s['id']).values(),key=lambda b:b[0]);bars=[b for b in bars if b[0]<=s['date']]
            # A missing market-wide weekday invalidates continuity; keep all bars for chart but calculate only confirmed contiguous tail.
            good=[];tail=[]
            for b in reversed(bars):
                if tail:
                    a=dt.date.fromisoformat(b[0])+dt.timedelta(days=1);stop=dt.date.fromisoformat(tail[-1][0]);gap=False
                    while a<stop:
                        if a.weekday()<5 and a.isoformat() not in closed and self.state['days'].get(s['market']+':'+a.isoformat(),{}).get('status')!='ok':gap=True;break
                        a+=dt.timedelta(days=1)
                    if gap:break
                tail.append(b)
            good=list(reversed(tail))
            metrics,event=latest(good,self.state.get('events',{}).get(s['id'],[]));s['metrics']=metrics;s['historyCount']=len(bars);s['historyStart']=bars[0][0] if bars else '';s['historyEnd']=bars[-1][0] if bars else ''
            if event:s['eventDate']=event;s['eventNotice']=f'{event} 偵測到除權息／參考價調整；相關指標需足夠新樣本'
            elif len(good)<len(bars):s['eventNotice']='歷史資料存在缺口，篩選指標僅使用最近連續已核對的資料'
            flows=self.state['flow'].get(s['id'],{})
            for field,name in [('foreign','foreignStreak'),('trust','trustStreak')]:
                streak=0;recent=sorted(flows,reverse=True)
                if not recent or recent[0]!=s.get('institutionDate') or s.get('institutionDate')!=s['date']:s['metrics'][name]=None;continue
                prev=None
                for day in recent:
                    if prev:
                        scan=dt.date.fromisoformat(day)+dt.timedelta(days=1);stop=dt.date.fromisoformat(prev)
                        if any((scan+dt.timedelta(days=i)).weekday()<5 and (scan+dt.timedelta(days=i)).isoformat() not in closed for i in range((stop-scan).days)):break
                    if flows[day].get(field) is None or flows[day][field]<=0:break
                    streak+=1;prev=day
                # one day with no prior history is a known minimum, not an established exact streak.
                s['metrics'][name]=streak if streak<len(recent) else None
        target_dates=self.target_dates(latest_date,closed)
        completed=sum(all(self.state['days'].get(m+':'+d,{}).get('status')=='ok' for m in ('TWSE','TPEX')) for d in target_dates)
        if completed<len(target_dates):self.warnings.append(f'歷史資料補建進度 {completed}/{len(target_dates)} 個候選交易日；缺漏不以 0 補值。')
        sources_ok=all(self.sources[k]['ok'] for k in ('tw_quotes','ot_quotes','tw_master','ot_master'))
        snapshot={'meta':{'schemaVersion':1,'formulaVersion':FORMULA_VERSION,'generatedAt':self.nowtext,'date':latest_date,'targetDate':expected,'status':'ready' if sources_ok and all(day>=expected for day in market_dates.values()) else 'partial','sources':self.sources,'history':{'targetDays':len(target_dates),'completedDays':completed,'stockCount':sum(s['historyCount']>1 for s in stocks)},'warnings':self.warnings,'priceMode':'raw','volumeUnit':'shares','marginUnit':'trading_units','currency':'TWD'},'stocks':sorted(stocks,key=lambda s:(s['market'],s['code'])),'indices':self.indices()}
        if self.old.get('meta',{}).get('date','')>latest_date:raise RuntimeError('新資料日期倒退，保留原快照')
        self.flush();save(OUT/'market.json',snapshot)
        print(f'Published {len(stocks)} securities, quote date {latest_date}, history {completed}/{len(target_dates)}, {len(self.warnings)} warnings',flush=True)
    def fill_extras(self,stocks):
        for market,prefix in [('TWSE','tw'),('TPEX','ot')]:
            for r in self.rows[prefix+'_value']:
                code=clean(r.get('Code') if market=='TWSE' else r.get('SecuritiesCompanyCode'));s=stocks.get(market+':'+code)
                if s:
                    pe=number(r.get('PEratio') if market=='TWSE' else r.get('PriceEarningRatio'))
                    s.update(pe=pe if pe and pe>0 else None,pb=number(r.get('PBratio') if market=='TWSE' else r.get('PriceBookRatio')),yield_=None)
                    s.pop('yield_',None);s['yield']=number(r.get('DividendYield') if market=='TWSE' else r.get('YieldRatio'));s['valuationDate']=date(r.get('Date'))
            for r in self.rows[prefix+'_revenue']:
                s=stocks.get(market+':'+clean(r.get('公司代號')))
                if s and s['type']=='stock':s.update(revenueYoY=number(r.get('營業收入-去年同月增減(%)')),revenueMoM=number(r.get('營業收入-上月比較增減(%)')),revenuePeriod=period(r.get('資料年月')))
            for r in self.rows[prefix+'_eps']:
                s=stocks.get(market+':'+clean(r.get('公司代號') if market=='TWSE' else r.get('SecuritiesCompanyCode')))
                y=number(r.get('年度') if market=='TWSE' else r.get('Year'));q=clean(r.get('季別'))
                if s and s['type']=='stock' and y:s.update(eps=number(r.get('基本每股盈餘(元)') if market=='TWSE' else r.get('基本每股盈餘')),epsPeriod=f'{int(y)+1911 if y<1911 else int(y)} Q{q} 累計')
            for r in self.rows[prefix+'_events']:
                code=clean(r.get('Code') if market=='TWSE' else r.get('SecuritiesCompanyCode'));day=date(r.get('Date') if market=='TWSE' else r.get('ExRrightsExDividendDate'))
                if day:
                    key=market+':'+code;self.state['events'][key]=sorted(set(self.state['events'].get(key,[]))|{day})
        tw_dates=[s['date'] for s in stocks.values() if s['market']=='TWSE'];day=max(tw_dates,default='')
        if day:
            stamp=day.replace('-','')
            payload=self.source('tw_flow','上市三大法人',f'https://www.twse.com.tw/rwd/zh/fund/T86?date={stamp}&selectType=ALLBUT0999&response=json',validator=lambda x:flow_rows(x,day))
            actual=date(payload.get('date')) if isinstance(payload,dict) else ''
            if actual:
                try:
                    for code,extra in flow_rows(payload,actual).items():
                        if 'TWSE:'+code in stocks:stocks['TWSE:'+code].update(extra)
                except ValueError:pass
            payload=self.source('tw_margin','上市融資融券',f'https://www.twse.com.tw/rwd/zh/marginTrading/MI_MARGN?date={stamp}&selectType=ALL&response=json',validator=lambda x:margin_rows(x,day))
            actual=date(payload.get('date')) if isinstance(payload,dict) else ''
            if actual:
                try:
                    for code,extra in margin_rows(payload,actual).items():
                        if 'TWSE:'+code in stocks:stocks['TWSE:'+code].update(extra)
                except ValueError:pass
        for r in self.rows['ot_flow']:
            s=stocks.get('TPEX:'+clean(r.get('SecuritiesCompanyCode')))
            if s:s.update(foreign=number(r.get('Foreign Investors include Mainland Area Investors (Foreign Dealers excluded)-Difference')),trust=number(r.get('SecuritiesInvestmentTrustCompanies-Difference')),dealer=number(r.get('Dealers-Difference')),institutionDate=date(r.get('Date')))
        for r in self.rows['ot_margin']:
            s=stocks.get('TPEX:'+clean(r.get('SecuritiesCompanyCode')))
            if s:
                a,b,c,d=[number(r.get(k)) for k in ('MarginPurchaseBalance','MarginPurchaseBalancePreviousDay','ShortSaleBalance','ShortSaleBalancePreviousDay')]
                s.update(marginChange=a-b if a is not None and b is not None else None,shortChange=c-d if c is not None and d is not None else None,marginDate=date(r.get('Date')))
        for s in stocks.values():
            if s.get('institutionDate'):
                f=self.state['flow'].setdefault(s['id'],{});f[s['institutionDate']]={k:s.get(k) for k in ('foreign','trust','dealer')}
                for old in sorted(f)[:-300]:del f[old]
    def target_dates(self,end,closed):
        last=dt.date.fromisoformat(end);start=last.replace(year=last.year-self.args.history_years) if (last.month,last.day)!=(2,29) else last.replace(year=last.year-self.args.history_years,day=28)
        dates=[];d=last
        while d>=start:
            if d.weekday()<5 and d.isoformat() not in closed:dates.append(d.isoformat())
            d-=dt.timedelta(days=1)
        return dates
    def backfill(self,universe,end,closed):
        if not self.args.batch_days:return
        candidates=self.target_dates(end,closed);done=0
        for day in candidates:
            missing=[m for m in ('TWSE','TPEX') if self.state['days'].get(m+':'+day,{}).get('status')!='ok']
            if not missing:continue
            if done>=self.args.batch_days:break
            attempted=False
            for market in missing:
                key=market+':'+day;prev=self.state['days'].get(key,{})
                if prev.get('retryAfter',0)>time.time():continue
                url=(f'https://www.twse.com.tw/rwd/zh/afterTrading/MI_INDEX?date={day.replace("-","")}&type=ALLBUT0999&response=json' if market=='TWSE' else f'https://www.tpex.org.tw/www/zh-tw/afterTrading/otc?date={day.replace("-","/")}&type=EW&response=json')
                if urllib.parse.urlparse(url).netloc in self.fetch.blocked_hosts:continue
                attempted=True
                try:
                    bars=historical(self.fetch.get(url),market,day)
                    for code,b in bars.items():
                        sid=market+':'+code
                        if sid in universe:self.put_bar(sid,b)
                    self.state['days'][key]={'status':'ok','at':self.nowtext,'count':len(bars)}
                    print(f'History {market} {day}: {len(bars)}',flush=True)
                except Exception as e:
                    attempts=prev.get('attempts',0)+1
                    self.state['days'][key]={'status':'missing','attempts':attempts,'error':str(e)[:160],'at':self.nowtext,'retryAfter':time.time()+min(7*86400,86400*attempts)}
                    print(f'History unavailable {market} {day}: {e}',flush=True)
                self.flush()
            if attempted:done+=1
            if all(h in self.fetch.blocked_hosts for h in ('www.twse.com.tw','www.tpex.org.tw')):break
        if self.fetch.blocked_hosts:self.warnings.append('部分官方主機暫時拒絕存取；本輪已停止該來源，下一輪再續傳。')
    def indices(self):
        result=[]
        for r in self.rows.get('tw_index',[]):
            if r.get('指數')=='發行量加權股價指數':
                change=number(r.get('漲跌點數'));sign=-1 if clean(r.get('漲跌'))=='-' else 1
                result.append({'name':'加權指數','close':number(r.get('收盤指數')),'change':change*sign if change is not None else None,'pct':number(r.get('漲跌百分比')),'date':date(r.get('日期'))});break
        rows=self.rows.get('ot_index',[])
        if rows:
            r=max(rows,key=lambda r:date(r.get('Date')))
            c=number(r.get('Close'));change=number(r.get('Change'));p=c-change if c is not None and change is not None else None
            result.append({'name':'櫃買指數','close':c,'change':change,'pct':change/p*100 if p else None,'date':date(r.get('Date'))})
        return result

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--batch-days',type=int,default=0,help='每次補建的歷史候選交易日數（0=僅每日更新）');p.add_argument('--history-years',type=int,default=5);p.add_argument('--delay',type=float,default=1.5);p.add_argument('--cached',action='store_true',help='僅用已取得來源快取重算，供離線檢查');args=p.parse_args()
    if args.cached and args.batch_days:raise SystemExit('--cached 不可與歷史網路補建同時使用')
    if not 0<=args.batch_days<=1500 or not 1<=args.history_years<=10 or args.delay<1:raise SystemExit('參數超出範圍；請求間隔至少 1 秒')
    Pipeline(args).run()
if __name__=='__main__':main()

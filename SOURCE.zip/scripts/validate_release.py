import json,sys
from pathlib import Path
root=Path(__file__).resolve().parent.parent
dist=root/'dist'
size=sum(p.stat().st_size for p in dist.rglob('*') if p.is_file())
assert size<850_000_000,f'網站 {size} bytes 過大；請先封存歷史資料，避免超過 Pages 限制'
for p in ['index.html','sw.js','version.json','manifest.webmanifest','icon-192.png','icon-512.png','SETUP.html','market.json']:
    assert (dist/p).is_file(),f'缺少 {p}'
d=json.loads((dist/'market.json').read_text())
assert d['meta']['schemaVersion']==1 and len(d['stocks'])>500,'行情快照未準備完成'
ids=[s['id'] for s in d['stocks']];assert len(ids)==len(set(ids)),'股票重複'
assert not any(p.name.endswith('.tmp') for p in dist.rglob('*')),'不可發布暫存檔'
print(f'Release verified: {len(ids)} securities; {size/1024/1024:.1f} MiB; data date {d["meta"]["date"]}')

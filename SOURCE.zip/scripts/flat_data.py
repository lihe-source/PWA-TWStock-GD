"""Reversible flat history format and explicit Pages artifact staging."""
from __future__ import annotations
import argparse
import json
from pathlib import Path
import re
import shutil
import zipfile

SHARDS = 32


def history_file(sid):
    h = 0
    for c in sid:
        h = (h * 31 + ord(c)) & 0xffffffff
    return f'history-{h % SHARDS:02d}.json'


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))


def save(path, data):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + '.tmp')
    temp.write_text(json.dumps(data, ensure_ascii=False, separators=(',', ':'), allow_nan=False) + '\n', encoding='utf-8')
    temp.replace(path)


def valid_id(sid):
    return isinstance(sid, str) and re.fullmatch(r'(TWSE|TPEX):[A-Za-z0-9]+', sid)


def pack(project, flat):
    project, flat = Path(project), Path(flat)
    flat.mkdir(parents=True, exist_ok=True)
    market = read(project / 'public/data/market.json')
    if not market.get('meta') or not market.get('stocks'):
        raise ValueError('Refusing to publish an empty market')
    groups = {f'history-{i:02d}.json': {} for i in range(SHARDS)}
    for path in sorted((project / 'public/data/history').glob('*.json')):
        sid = path.stem.replace('-', ':', 1)
        if not valid_id(sid):
            raise ValueError(f'Invalid security id: {sid}')
        bars = read(path)
        if not isinstance(bars, list):
            raise ValueError(f'Invalid history: {sid}')
        groups[history_file(sid)][sid] = bars
    for name, data in groups.items():
        save(flat / name, data)
    save(flat / 'market.json', market)
    return sum(len(group) for group in groups.values())


def unpack(flat, project):
    flat, project = Path(flat), Path(project)
    market = read(flat / 'market.json')
    if not market.get('meta') or not market.get('stocks'):
        raise ValueError('Invalid market')
    # Validate all input before writing; never accept paths from a JSON key.
    histories = {}
    for i in range(SHARDS):
        name = f'history-{i:02d}.json'
        group = read(flat / name)
        if not isinstance(group, dict):
            raise ValueError(f'Invalid shard: {name}')
        for sid, bars in group.items():
            if not valid_id(sid) or history_file(sid) != name or not isinstance(bars, list):
                raise ValueError(f'Invalid entry in {name}')
            histories[sid] = bars
    for sid, bars in histories.items():
        save(project / 'public/data/history' / (sid.replace(':', '-') + '.json'), bars)
    save(project / 'public/data/market.json', market)
    state = flat / 'PIPELINE_STATE.zip'
    if state.exists():
        # This archive contains only official-source public data and pipeline progress.
        with zipfile.ZipFile(state) as z:
            for info in z.infolist():
                parts = Path(info.filename).parts
                if not parts or parts[0] != 'data-store' or '..' in parts or '\\' in info.filename or info.is_dir():
                    raise ValueError('Invalid pipeline state archive')
            z.extractall(project)
    return len(histories)


def stage(flat, project, output):
    flat, project, output = Path(flat), Path(project), Path(output)
    files = read(flat / 'SITE_FILES.json')
    if not isinstance(files, list) or 'index.html' not in files:
        raise ValueError('Missing site file inventory')
    if any(not isinstance(n, str) or n != Path(n).name or '/' in n or '\\' in n or n in ('.', '..') for n in files):
        raise ValueError('Invalid site file inventory')
    output.mkdir(parents=True, exist_ok=False)
    for name in files:
        shutil.copy2(flat / name, output / name)
    return pack(project, output)


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('command', choices=['pack', 'unpack', 'stage', 'clean'])
    p.add_argument('--flat', type=Path, required=True)
    p.add_argument('--project', type=Path, default=Path('.'))
    p.add_argument('--output', type=Path, default=Path('.pages'))
    a = p.parse_args()
    if a.command == 'pack':
        print('Packed histories:', pack(a.project, a.flat))
    elif a.command == 'unpack':
        print('Restored histories:', unpack(a.flat, a.project))
    elif a.command == 'stage':
        print('Staged histories:', stage(a.flat, a.project, a.output))
    else:
        shutil.rmtree(a.flat / 'data', ignore_errors=True)


if __name__ == '__main__':
    main()

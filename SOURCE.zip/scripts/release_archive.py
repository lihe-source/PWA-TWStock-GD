"""Build and verify a complete, portable ZIP using Python's standard library."""
import argparse
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import tempfile
import zipfile

MANIFEST = 'RELEASE_MANIFEST.json'
EXCLUDE = {'node_modules', '.git', '.openai', '.sites-runtime', '__pycache__',
           '.market-store', 'test-results', '.data-cache'}


def digest(data):
    return hashlib.sha256(data).hexdigest()


def safe_name(name):
    parts = PurePosixPath(name).parts
    return bool(parts) and not name.startswith('/') and '\\' not in name and all(
        p not in ('.', '..') and not re.search(r'[<>:"|?*\x00-\x1f]', p)
        and not p.endswith((' ', '.')) for p in parts)


def verify_archive(archive):
    archive = Path(archive)
    # A complete ZIP must end in an end-of-central-directory record.
    with archive.open('rb') as f:
        f.seek(max(0, archive.stat().st_size - 65557))
        tail = f.read()
    pos = tail.rfind(b'PK\x05\x06')
    if pos < 0 or pos + 22 > len(tail):
        raise ValueError('ZIP 結尾目錄缺失，檔案可能未完整寫入或下載')
    comment_size = int.from_bytes(tail[pos + 20:pos + 22], 'little')
    if pos + 22 + comment_size != len(tail):
        raise ValueError('ZIP 結尾不完整')
    with zipfile.ZipFile(archive) as z:
        names = z.namelist()
        if len(names) != len(set(names)) or not all(safe_name(n) for n in names):
            raise ValueError('ZIP 含重複或不安全的檔案路徑')
        folders = {PurePosixPath(n).parts[0] for n in names}
        if folders != {archive.stem}:
            raise ValueError('ZIP 內唯一外層資料夾必須與壓縮檔同名')
        prefix = archive.stem + '/'
        m = json.loads(z.read(prefix + MANIFEST))
        expected = {prefix + p for p in m['files']} | {prefix + MANIFEST}
        if set(names) != expected:
            raise ValueError('ZIP 檔案清單不完整')
        bad = z.testzip()
        if bad:
            raise ValueError('ZIP CRC 錯誤：' + bad)
        for path, entry in m['files'].items():
            data = z.read(prefix + path)
            if len(data) != entry['bytes'] or digest(data) != entry['sha256']:
                raise ValueError('ZIP 檔案校驗失敗：' + path)
    return {'files': len(names), 'bytes': archive.stat().st_size,
            'sha256': digest(archive.read_bytes())}


def build_archive(root, output):
    root, output = Path(root).resolve(), Path(output).resolve()
    if output.stem != root.name:
        raise ValueError('資料夾與 ZIP 名稱必須相同')
    files = []
    for directory, subdirs, filenames in os.walk(root):
        subdirs[:] = sorted(d for d in subdirs if d not in EXCLUDE and not Path(directory, d).is_symlink())
        for name in sorted(filenames):
            p = Path(directory, name)
            if p.is_symlink() or p == output or name == MANIFEST or name.startswith(('.env', '__qa-')):
                continue
            if name.endswith(('.pyc', '.tsbuildinfo', '.tmp')) or name == '.DS_Store':
                continue
            relative = p.relative_to(root).as_posix()
            if not safe_name(root.name + '/' + relative):
                raise ValueError('檔名無法在 Windows 安全解壓：' + relative)
            files.append((p, relative))
    manifest = {'schemaVersion': 1, 'files': {r: {'bytes': p.stat().st_size,
                'sha256': digest(p.read_bytes())} for p, r in files}}
    # Work in a separate directory: the final download path is never half-written.
    output.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='.zip-build-', dir=output.parent) as temp:
        staged = Path(temp, output.name)
        with staged.open('w+b') as stream:
            with zipfile.ZipFile(stream, 'w', zipfile.ZIP_DEFLATED, compresslevel=6,
                                 allowZip64=False, strict_timestamps=False) as z:
                for p, relative in files:
                    z.write(p, root.name + '/' + relative)
                z.writestr(root.name + '/' + MANIFEST,
                           json.dumps(manifest, ensure_ascii=False, indent=2) + '\n')
            stream.flush()
            os.fsync(stream.fileno())
        result = verify_archive(staged)
        os.replace(staged, output)
    checksum = output.with_suffix('.zip.sha256')
    checksum.write_text(f'{result["sha256"]}  {output.name}\n', encoding='ascii')
    return result


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--verify', type=Path, help='檢查既有 ZIP 的目錄、CRC 與逐檔 SHA-256')
    args = parser.parse_args()
    if args.verify:
        result = verify_archive(args.verify)
    else:
        root = Path(__file__).resolve().parent.parent
        result = build_archive(root, root.with_suffix('.zip'))
    print(json.dumps(result, ensure_ascii=False))

from pathlib import Path
import json,os
p=Path('public/data/market.json')
if p.exists():
    d=json.loads(p.read_text());m=d['meta']
    text=f"# 股序資料更新\n\n行情日：{m['date']}  \n整理時間：{m['generatedAt']}  \n證券數：{len(d['stocks'])}  \n歷史已完成：{m['history']['completedDays']}/{m['history']['targetDays']}\n\n"
    text+='|來源|狀態|日期|筆數|\n|---|---|---|---|\n'
    for s in m['sources'].values():text+=f"|{s['name']}|{'成功' if s['ok'] else '保留舊資料'}|{s.get('date','')}|{s.get('count',0)}|\n"
    text+='\n'+'\n'.join('- '+w for w in m.get('warnings',[]))
else:text='## 未取得可發布行情\n請查看擷取步驟錯誤。原有資料不會被空值覆蓋。\n'
if os.getenv('GITHUB_STEP_SUMMARY'):
    with open(os.environ['GITHUB_STEP_SUMMARY'],'a',encoding='utf-8') as f:f.write(text)
print(text)

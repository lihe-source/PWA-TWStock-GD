import fs from 'node:fs';
const version=process.argv[2];if(!/^\d+\.\d+\.\d+$/.test(version||''))throw new Error('用法：node scripts/bump-version.mjs 1.1.0');
const p=JSON.parse(fs.readFileSync('package.json'));p.version=version;fs.writeFileSync('package.json',JSON.stringify(p,null,2)+'\n');
const lock=JSON.parse(fs.readFileSync('package-lock.json'));lock.version=version;lock.packages[''].version=version;fs.writeFileSync('package-lock.json',JSON.stringify(lock,null,2)+'\n');
const v=JSON.parse(fs.readFileSync('public/version.json'));v.version=version;v.releasedAt=new Date().toISOString().slice(0,10);fs.writeFileSync('public/version.json',JSON.stringify(v,null,2)+'\n');
const file='src/pwa.ts';fs.writeFileSync(file,fs.readFileSync(file,'utf8').replace(/export const VERSION='[^']+'/,`export const VERSION='${version}'`));
console.log('版本已更新。請編輯 public/version.json notes，執行 npm run check && npm run build 後提交。');

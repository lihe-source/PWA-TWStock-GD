import type {Bar} from './types.ts';
export const FORMULA_VERSION='1.0.0';
export function sma(a:(number|null)[],n:number):(number|null)[]{return a.map((_,i)=>i<n-1||a.slice(i-n+1,i+1).some(v=>v===null)?null:a.slice(i-n+1,i+1).reduce<number>((s,x)=>s+(x??0),0)/n)}
export function ema(a:(number|null)[],n:number):(number|null)[]{let prev:number|null=null;return a.map((v,i)=>{if(v===null){prev=null;return null}if(prev===null){const q=a.slice(Math.max(0,i-n+1),i+1);if(q.length<n||q.includes(null))return null;prev=q.reduce<number>((s,x)=>s+(x??0),0)/n}else prev=v*2/(n+1)+prev*(1-2/(n+1));return prev})}
export function indicators(bars:Bar[]){
 const c=bars.map(b=>b[4]),vol=bars.map(b=>b[5]);const ma:Record<string,(number|null)[]>={};
 for(const n of [5,10,20,60,120,240])ma['ma'+n]=sma(c,n);
 const e12=ema(c,12),e26=ema(c,26),dif=c.map((_,i)=>e12[i]===null||e26[i]===null?null:e12[i]!-e26[i]!),dea=ema(dif,9),hist=dif.map((v,i)=>v===null||dea[i]===null?null:v-dea[i]!);
 let k=50,d=50;const ks:(number|null)[]=[],ds:(number|null)[]=[];
 const rsi:(number|null)[]=Array(c.length).fill(null);let gain=0,loss=0,count=0;
 for(let i=0;i<c.length;i++){
  const q=bars.slice(Math.max(0,i-8),i+1);if(q.length===9&&q.every(b=>b[2]!==null&&b[3]!==null)&&c[i]!==null){const hi=Math.max(...q.map(b=>b[2]!)),lo=Math.min(...q.map(b=>b[3]!));const rsv=hi===lo?50:100*(c[i]!-lo)/(hi-lo);k=k*2/3+rsv/3;d=d*2/3+k/3;ks.push(k);ds.push(d)}else{ks.push(null);ds.push(null)}
  if(i===0)continue;if(c[i]===null||c[i-1]===null){gain=0;loss=0;count=0;continue}const delta=c[i]!-c[i-1]!;
  if(count<14){gain+=Math.max(0,delta);loss+=Math.max(0,-delta);count++;if(count===14){gain/=14;loss/=14}}else{gain=(gain*13+Math.max(0,delta))/14;loss=(loss*13+Math.max(0,-delta))/14}
  if(count>=14)rsi[i]=gain===0&&loss===0?50:loss===0?100:100-100/(1+gain/loss);
 }
 const std=c.map((_,i)=>ma.ma20[i]===null?null:Math.sqrt(c.slice(i-19,i+1).reduce<number>((s,x)=>s+(x!-ma.ma20[i]!)**2,0)/20));
 return {...ma,k:ks,d:ds,rsi,dif,dea,hist,upper:ma.ma20.map((v,i)=>v===null?null:v+2*std[i]!),lower:ma.ma20.map((v,i)=>v===null?null:v-2*std[i]!),volume:vol};
}
export function aggregate(bars:Bar[],period:'D'|'W'|'M'):Bar[]{if(period==='D')return bars;const out:Bar[]=[];let last='';for(const b of bars){const dt=new Date(b[0]+'T00:00:00Z');if(period==='W')dt.setUTCDate(dt.getUTCDate()-((dt.getUTCDay()+6)%7));const key=period==='M'?b[0].slice(0,7):dt.toISOString().slice(0,10);if(key!==last){out.push([...b]);last=key}else{const x=out[out.length-1];x[0]=b[0];if(x[1]===null)x[1]=b[1];x[2]=b[2]===null?x[2]:x[2]===null?b[2]:Math.max(x[2],b[2]);x[3]=b[3]===null?x[3]:x[3]===null?b[3]:Math.min(x[3],b[3]);if(b[4]!==null)x[4]=b[4];x[5]+=b[5]}}return out}

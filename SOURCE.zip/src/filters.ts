import type {FilterSpec,Stock,Membership} from './types.ts';
export const fields:Record<string,{label:string;unit?:string;category:string;dated?:string}>={
 close:{label:'收盤價',unit:'元',category:'價量'},pct:{label:'漲跌幅',unit:'%',category:'價量'},volumeLots:{label:'成交量',unit:'張',category:'價量'},amountMillions:{label:'成交金額',unit:'百萬元',category:'價量'},volumeRatio:{label:'相對前20日均量',unit:'倍',category:'價量'},break20:{label:'突破前20日高點',unit:'1=是',category:'技術'},
 pe:{label:'本益比',unit:'倍',category:'基本',dated:'valuationDate'},pb:{label:'股價淨值比',unit:'倍',category:'基本',dated:'valuationDate'},yield:{label:'殖利率',unit:'%',category:'基本',dated:'valuationDate'},revenueYoY:{label:'月營收年增率',unit:'%',category:'基本'},revenueMoM:{label:'月營收月增率',unit:'%',category:'基本'},eps:{label:'本年累計 EPS',unit:'元',category:'基本'},
 ma5:{label:'5日均線',unit:'元',category:'技術'},ma20:{label:'20日均線',unit:'元',category:'技術'},ma60:{label:'60日均線',unit:'元',category:'技術'},above20:{label:'股價高於20日線',unit:'1=是',category:'技術'},bullish:{label:'5>20>60日線',unit:'1=是',category:'技術'},golden:{label:'5/20日線黃金交叉',unit:'1=是',category:'技術'},k:{label:'KD：K',category:'技術'},d:{label:'KD：D',category:'技術'},rsi:{label:'RSI (14)',category:'技術'},hist:{label:'MACD 柱 (DIF−DEA)',category:'技術'},
 foreign:{label:'外資買賣超',unit:'股',category:'籌碼',dated:'institutionDate'},trust:{label:'投信買賣超',unit:'股',category:'籌碼',dated:'institutionDate'},dealer:{label:'自營商買賣超',unit:'股',category:'籌碼',dated:'institutionDate'},foreignStreak:{label:'外資連買天數',unit:'日',category:'籌碼',dated:'institutionDate'},trustStreak:{label:'投信連買天數',unit:'日',category:'籌碼',dated:'institutionDate'},marginChange:{label:'融資餘額增減',unit:'張',category:'籌碼',dated:'marginDate'},shortChange:{label:'融券餘額增減',unit:'張',category:'籌碼',dated:'marginDate'}
};
export const emptySpec=():FilterSpec=>({query:'',market:'all',type:'stock',industry:'all',folderId:'',mode:'all',groups:[{id:'main',mode:'all',rules:[]}],requireFresh:true});
export function fieldValue(s:Stock,f:string):number|null{if(f==='volumeLots')return s.volume/1000;if(f==='amountMillions')return s.amount/1e6;const v=(s as unknown as Record<string,unknown>)[f]??s.metrics[f];return typeof v==='number'&&Number.isFinite(v)?v:null}
export function evaluate(s:Stock,spec:FilterSpec,target:string,memberships:Membership[]):{pass:boolean;missing:boolean}{
 if(spec.query&&!`${s.code} ${s.name}`.toLowerCase().includes(spec.query.toLowerCase()))return{pass:false,missing:false};
 if(spec.market!=='all'&&s.market!==spec.market||spec.type!=='all'&&s.type!==spec.type||spec.industry!=='all'&&s.industry!==spec.industry)return{pass:false,missing:false};
 if(spec.folderId&&!memberships.some(m=>m.stockId===s.id&&m.folderId===spec.folderId))return{pass:false,missing:false};
 if(spec.requireFresh&&s.date!==target)return{pass:false,missing:true};
 const groups=spec.groups.filter(g=>g.rules.length);if(!groups.length)return{pass:true,missing:false};
 const evaluateValues=(a:(boolean|null)[],mode:'all'|'any'):boolean|null=>mode==='all'?(a.includes(false)?false:a.includes(null)?null:true):(a.includes(true)?true:a.includes(null)?null:false);
 const statuses=groups.map(g=>evaluateValues(g.rules.map(r=>{const v=fieldValue(s,r.field),dateKey=fields[r.field]?.dated;if(v===null||(spec.requireFresh&&dateKey&&(s as unknown as Record<string,unknown>)[dateKey]!==target))return null;
 if(fields[r.field]?.category==='技術'&&s.historyEnd!==s.date)return null;
 if(r.op==='gt')return v>r.value;if(r.op==='gte')return v>=r.value;if(r.op==='lt')return v<r.value;if(r.op==='lte')return v<=r.value;return v===r.value}),g.mode));
 const result=evaluateValues(statuses,spec.mode);return{pass:result===true,missing:result===null};
}
export function csvCell(v:unknown):string{let s=String(v??'');if(/^[=+@\t\r]/.test(s)||(/^-/ .test(s)&&!Number.isFinite(Number(s))))s="'"+s;return '"'+s.replaceAll('"','""')+'"'}

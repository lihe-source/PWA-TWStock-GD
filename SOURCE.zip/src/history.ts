/** Fixed 32-way shards, shared with scripts/flat_data.py. */
export function historyFile(id:string):string {
 let hash=0;for(const c of id)hash=(Math.imul(hash,31)+c.charCodeAt(0))>>>0;
 return `history-${String(hash%32).padStart(2,'0')}.json`;
}

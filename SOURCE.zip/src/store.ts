import {uuid} from './id.ts';
import type {Operation,UserState,Folder,Membership,Note,Preset,Snapshot,Config,Entity} from './types.ts';
const DB='twstock-v1';let dbPromise:Promise<IDBDatabase>|null=null;
export function db(){if(!dbPromise)dbPromise=new Promise((resolve,reject)=>{const q=indexedDB.open(DB,1);q.onupgradeneeded=()=>{q.result.createObjectStore('kv');q.result.createObjectStore('ops',{keyPath:'id'})};q.onsuccess=()=>resolve(q.result);q.onerror=()=>reject(q.error)});return dbPromise}
export async function readKV<T>(key:string,fallback:T):Promise<T>{const d=await db();return new Promise((resolve,reject)=>{const q=d.transaction('kv').objectStore('kv').get(key);q.onsuccess=()=>resolve(q.result??fallback);q.onerror=()=>reject(q.error)})}
export async function writeKV(key:string,value:unknown){const d=await db();return new Promise<void>((resolve,reject)=>{const tx=d.transaction('kv','readwrite');tx.objectStore('kv').put(value,key);tx.oncomplete=()=>resolve();tx.onerror=()=>reject(tx.error)})}
export async function allOps():Promise<Operation[]>{const d=await db();return new Promise((resolve,reject)=>{const q=d.transaction('ops').objectStore('ops').getAll();q.onsuccess=()=>resolve(q.result);q.onerror=()=>reject(q.error)})}
const record=(v:any)=>v!==null&&typeof v==='object'&&!Array.isArray(v);
const str=(v:any,max=1000)=>typeof v==='string'&&v.length<=max;
const finite=(v:any)=>typeof v==='number'&&Number.isFinite(v);
const optionalNumber=(v:any)=>v===null||finite(v);
const date=(v:any)=>str(v,50)&&Number.isFinite(Date.parse(v));
function validSpec(s:any):boolean{return record(s)&&['query','market','type','industry','folderId'].every(k=>str(s[k]))&&['all','any'].includes(s.mode)&&typeof s.requireFresh==='boolean'&&Array.isArray(s.groups)&&s.groups.length<=100&&s.groups.every((g:any)=>record(g)&&str(g.id)&&['all','any'].includes(g.mode)&&Array.isArray(g.rules)&&g.rules.length<=100&&g.rules.every((r:any)=>record(r)&&str(r.id)&&str(r.field)&&['gt','gte','lt','lte','eq'].includes(r.op)&&finite(r.value)))}
function validValue(entity:string,key:string,v:any):boolean{
 if(!record(v))return false;
 if(entity==='prefs')return Object.keys(v).every(k=>k==='theme')&&(v.theme==='light'||v.theme==='dark');
 if(v.id!==key)return false;
 if(entity==='folder')return str(v.name)&&str(v.color,30)&&/^#[0-9a-f]{3,8}$/i.test(v.color)&&finite(v.order);
 if(entity==='membership')return str(v.folderId)&&str(v.stockId)&&date(v.addedAt)&&optionalNumber(v.price);
 if(entity==='note')return str(v.stockId)&&str(v.text,100000)&&str(v.tag)&&str(v.status)&&date(v.createdAt)&&(v.conflictOf===undefined||str(v.conflictOf));
 if(entity==='preset')return str(v.name)&&validSpec(v.spec);
 if(entity==='snapshot')return str(v.name)&&date(v.date)&&date(v.createdAt)&&validSpec(v.spec)&&Array.isArray(v.rows)&&v.rows.length<=20000&&v.rows.every((r:any)=>record(r)&&['id','code','name'].every(k=>str(r[k]))&&date(r.date)&&optionalNumber(r.close)&&optionalNumber(r.pct));
 return false;
}
export function validOps(raw:unknown):raw is Operation[]{return Array.isArray(raw)&&raw.length<=500000&&raw.every(o=>record(o)&&str(o.id,199)&&o.id.length>0&&str(o.key,299)&&o.key.length>0&&str(o.device,200)&&Number.isSafeInteger(o.clock)&&o.clock>=0&&date(o.at)&&(o.base===undefined||str(o.base,199))&&['folder','membership','note','preset','snapshot','prefs'].includes(o.entity)&&['put','delete'].includes(o.action)&&(o.action==='delete'||validValue(o.entity,o.key,o.value)))}
export function deletedRecords(ops:Operation[]):Operation[]{
 const latest=new Map<string,Operation>(),values=new Map<string,Operation>();
 for(const op of [...ops].sort((a,b)=>a.clock-b.clock||a.id.localeCompare(b.id))){const k=op.entity+':'+op.key;latest.set(k,op);if(op.action==='put')values.set(k,op)}
 return [...latest.entries()].filter(([k,o])=>o.action==='delete'&&values.has(k)).map(([k,o])=>({...o,value:values.get(k)!.value})).sort((a,b)=>b.clock-a.clock);
}
export async function insertOps(ops:Operation[]){if(!validOps(ops))throw new Error('記錄格式不正確或版本不相容');const d=await db();return new Promise<void>((resolve,reject)=>{const tx=d.transaction('ops','readwrite');for(const op of ops)tx.objectStore('ops').put(op);tx.oncomplete=()=>{window.dispatchEvent(new Event('user-data'));resolve()};tx.onerror=()=>reject(tx.error)})}
export function reduceOps(ops:Operation[]):UserState{
 const entries=new Map<string,Operation>();const notes=new Map<string,Note>();const sorted=[...ops].sort((a,b)=>a.clock-b.clock||a.id.localeCompare(b.id));
 const seen=new Set<string>();for(const op of sorted){if(seen.has(op.id))continue;seen.add(op.id);const key=op.entity+':'+op.key,prev=entries.get(key);
  if(op.entity==='note'&&prev&&op.action==='put'&&prev.action==='put'&&op.base!==prev.id&&JSON.stringify(op.value)!==JSON.stringify(prev.value)){const n=prev.value as Note;notes.set(n.id+'~'+prev.id,{...n,id:n.id+'~'+prev.id,conflictOf:n.id,tag:'衝突副本'})}
  entries.set(key,op);
 }
 const s:UserState={folders:[],memberships:[],notes:[],presets:[],snapshots:[],prefs:{},revisions:{}};
 for(const [key,op]of entries){s.revisions[key]=op.id;if(op.entity==='note'){if(op.action==='delete')notes.delete(op.key);else notes.set(op.key,op.value as Note);continue}if(op.action==='delete')continue;const v=op.value!;if(op.entity==='folder')s.folders.push(v as Folder);else if(op.entity==='membership')s.memberships.push(v as Membership);else if(op.entity==='preset')s.presets.push(v as Preset);else if(op.entity==='snapshot')s.snapshots.push(v as Snapshot);else s.prefs={...s.prefs,...v}}
 s.notes=[...notes.values()];
 s.folders.sort((a,b)=>a.order-b.order||a.name.localeCompare(b.name));s.notes.sort((a,b)=>b.createdAt.localeCompare(a.createdAt));s.snapshots.sort((a,b)=>b.createdAt.localeCompare(a.createdAt));return s;
}
export async function mutate(entity:Operation['entity'],key:string,value:Entity|undefined,action:'put'|'delete'='put'){
 const ops=await allOps(),state=reduceOps(ops);let device=await readKV('device','');if(!device){device=uuid();await writeKV('device',device)}const clock=ops.reduce((max,o)=>Math.max(max,o.clock+1),Date.now());
 const op:Operation={id:uuid(),device,clock,at:new Date().toISOString(),entity,key,action,base:state.revisions[entity+':'+key],...(value?{value}:{})};await insertOps([op]);return op;
}
export const defaultConfig:Config={clientId:'',apiKey:'',appId:'',folderId:'',folderName:'',theme:'light',account:'',lastSync:'',repo:''};
export const getConfig=()=>readKV<Config>('config',defaultConfig);
export async function setConfig(c:Config){await writeKV('config',c);window.dispatchEvent(new Event('config-change'))}
export async function exportBackup(){return{app:'twstock',schemaVersion:1,exportedAt:new Date().toISOString(),operations:await allOps(),config:{...(await getConfig()),account:'',lastSync:''}}}
export async function importBackup(value:unknown){const b=value as {app?:string;schemaVersion?:number;operations?:unknown;config?:Config};if(!b||b.app!=='twstock'||b.schemaVersion!==1||!validOps(b.operations))throw new Error('不是支援的股序備份檔，或記錄格式不完整');await insertOps(b.operations);return b.operations.length}
export function backupConfig(raw:unknown):Config{const c={...defaultConfig};if(!record(raw))return c;for(const k of ['clientId','apiKey','appId','folderId','folderName','repo'] as const){const v=(raw as Record<string,unknown>)[k];if(str(v,2000))c[k]=v as string}if((raw as any).theme==='dark')c.theme='dark';return c}
export function download(filename:string,body:string,type='application/json'){const url=URL.createObjectURL(new Blob([body],{type}));const a=document.createElement('a');a.href=url;a.download=filename;a.click();setTimeout(()=>URL.revokeObjectURL(url),2000)}
